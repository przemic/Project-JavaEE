package pl.indev.utils;

public class Commons {

	public final static String REST_URL = "http://10.0.2.2:8080/Maven-web/rest/";
	public final static int USER_ID = 4;
	
	public final static int REQUEST_CITY = 10;
	public final static int REQUEST_PROGRESS_BAR = 11;
	public final static int REQUEST_VOTE = 12;
	
	
}
