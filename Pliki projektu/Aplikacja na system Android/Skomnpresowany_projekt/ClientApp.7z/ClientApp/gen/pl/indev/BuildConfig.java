/** Automatically generated file. DO NOT MODIFY */
package pl.indev;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}